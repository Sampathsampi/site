import React from 'react'

function Header() {
  return (
    <div class="header-2 pt-3 absolute top-0 left-0  w-full">

      <nav class="bg-white py-2 md:py-4 shadow-md mx-8">
        <div class="container px-4 mx-auto md:flex md:items-center">

          <div class="flex justify-between items-center">
            <a href="#" class="font-bold text-xl flex items-center">
              <img src="/Image/image.png" width={60}/>
              Partner Champion
            </a>
            <button class="border border-solid border-gray-600 px-3 py-1 rounded text-gray-600 opacity-50 hover:opacity-75 md:hidden" id="navbar-toggle">
              <i class="fas fa-bars"></i>
            </button>
          </div>

          <div class="hidden md:flex flex-col md:flex-row md:ml-auto mt-3 md:mt-0" id="navbar-collapse">
            <a href="#" class="p-2 lg:px-4 md:mx-2 text-indigo-600 rounded">Home</a>
            <a href="#" class="p-2 lg:px-4 md:mx-2 text-gray-600 rounded hover:bg-gray-200 hover:text-gray-700 transition-colors duration-300">About</a>
            <a href="#" class="p-2 lg:px-4 md:mx-2 text-gray-600 rounded hover:bg-gray-200 hover:text-gray-700 transition-colors duration-300">Features</a>
            <a href="#" class="p-2 lg:px-4 md:mx-2 text-gray-600 rounded hover:bg-gray-200 hover:text-gray-700 transition-colors duration-300">Pricing</a>
            <a href="#" class="p-2 lg:px-4 md:mx-2 text-gray-600 rounded hover:bg-gray-200 hover:text-gray-700 transition-colors duration-300">Contact</a>
            </div>
        </div>
      </nav>

    </div>
  )
}

export default Header