import React from 'react';
import { BrowserRouter, Route, Link, Routes } from "react-router-dom";
import Home from '../home/Home';
import Header from '../../components/header/Header';

function PageRouter() {
    return (
        <BrowserRouter>
            <Routes>
                
                <Route exact path="/" element={<Home/>} />
                
            </Routes></BrowserRouter>
    )
}

export default PageRouter