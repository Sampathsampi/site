import React from 'react'

function Home() {
  return (
    <div class="">

      <div class="h-screen banner pt-5">
        {/* bg-cover bg-[url('../public/Image/banner.jpg')] */}
        <div class="h-full flex justify-between items-center flex-wrap custom-container">
          <div className='w-1/2'>
            <h2 className='banner-heading'>THE NEW RULES OF CONTENT MARKETING FOR TECH AND SAAS COMPANIES</h2>
            <p className='banner-content'>How CMOs can grow at pace and scale.</p>
          </div>
          <div class="w-1/2 max-w-sm m-auto p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-6 md:p-8 dark:bg-gray-800 dark:border-gray-700">
            <form class="space-y-6" action="#">
              <h5 class="text-xl font-medium text-gray-900 dark:text-white">Subscribe with us</h5>
              <div>
                <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Your email</label>
                <input type="email" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="name@company.com" required />
              </div>
              <div class="flex items-start">
                <div class="flex items-start">
                  <div class="flex items-center h-5">
                    <input id="remember" type="checkbox" value="" class="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-blue-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800" required />
                  </div>
                  <label for="remember" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">Get every latest updates</label>
                </div>

              </div>
              <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Sbscribe</button>

            </form>
          </div>

        </div>
      </div>
      <div class="bg-white py-12 sm:py-16 lg:py-20">
  <div class="mx-auto px-4 sm:px-6 lg:px-8">
    <div class="lg:text-center">
      
    </div>

    <div class="">
      <div class="bg-white overflow-hidden">
        <div class="md:flex items-center">
          
          <div class="p-8 w-1/2">
           <h2 class="text-base text-indigo-600 font-semibold tracking-wide uppercase">About Us</h2>
      <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
        We are a team of passionate developers who love creating amazing software.
      </p>
      <p class="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia suscipit nisi vel hendrerit. Our consectetur adipiscing elit. Sed lacinia suscipit nisi vel hendrerit juit helen spotu nig.
      </p>
      <p class="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
        Sed lacinia suscipit lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia suscipit nisi vel hendrerit. Our consectetur adipiscing elit. Sed lacinia suscipit nisi vel hendrerit juit helen spotu nig.
      </p>
           </div>
          <div class="w-1/2 px-20">
            <img class="" src="https://static9.depositphotos.com/1005669/1153/i/450/depositphotos_11539661-stock-photo-fingerprint-access.jpg" alt=""/>
            
          </div>
        </div>
      </div>

      {/* <div class="cards bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="md:flex">
          <div class="md:flex-shrink-0">
            <img class="h-48 w-full object-cover" src="https://images.unsplash.com/photo-1494252713559-f26b4bf0b174" alt=""/>
          </div>
          <div class="p-8">
            <div class="uppercase tracking-wide text-sm text-indigo-500 font-semibold">Our History</div>
            <a href="#" class="block mt-1 text-lg leading-tight font-medium text-black hover:underline">From Humble Beginnings to Industry Leader</a>
            <p class="mt-2 text-gray-500">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia suscipit nisi vel hendrerit.</p>
          </div>
        </div>
      </div>

      <div class="cards bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="md:flex">
          <div class="md:flex-shrink-0">
            <img class="h-48 w-full object-cover" src="https://images.unsplash.com/photo-1519389950473-47ba0277781c" alt=""/>
          </div>
          <div class="p-8">
            <div class="uppercase tracking-wide text-sm text-indigo-500 font-semibold">Our Team</div>
            <a href="#" class="block mt-1 text-lg leading-tight font-medium text-black hover:underline">Meet Our Amazing Team of Experts</a>
            <p class="mt-2 text-gray-500">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia suscipit nisi vel hendrerit.</p>
          </div>
        </div>
      </div>

      <div class="cards bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="md:flex">
          <div class="md:flex-shrink-0">
            <img class="h-48 w-full object-cover" src="c" alt=""/>
          </div>
          <div class="p-8">
            <div class="uppercase tracking-wide text-sm text-indigo-500 font-semibold">Our Goals</div>
            <a href="#" class="block mt-1 text-lg leading-tight font-medium text-black hover:underline">Sed lacinia nisi</a>
            <p class="mt-2 text-gray-500">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia suscipit nisi vel hendrerit.</p>
          </div>
        </div>
      </div> */}
    </div>
  </div>
</div>

    </div>

  )
}

export default Home