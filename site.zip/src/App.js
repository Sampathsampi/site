
import './App.css';
import Footer from './components/footer/Footer';
import Header from './components/header/Header';
import PageRouter from './pages/router/Router';

function App() {
  return (
    <>
    <Header/>
    <PageRouter/>
    <Footer/>
    </>
  );
}

export default App;
