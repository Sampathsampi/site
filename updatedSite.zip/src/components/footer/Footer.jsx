import React from 'react'

function Footer() {
  return (
    <>
    <div class="bg-black bg-opacity-5	 pt-5">
   <div class="custom-container px-4 sm:px-6 text-gray-800 sm:grid md:grid-cols-4 sm:grid-cols-2 mx-auto">
     <div class="md:p-5 py-5">
      
       <a href="#" class="font-bold text-xl flex items-center">
              <img src="/Image/image.png" className='pr-2' width={60}/>
            Partner Champion
            </a>
      
     </div>
      <div class="md:p-5 py-5">
         <div class="text-sm uppercase text-indigo-600 font-bold">Resources</div>
         <a class="my-3 block" href="/#">Documentation <span class="text-teal-600 text-xs p-1"></span></a><a class="my-3 block" href="/#">Tutorials <span class="text-teal-600 text-xs p-1"></span></a><a class="my-3 block" href="/#">Support <span class="text-teal-600 text-xs p-1">New</span></a> 
      </div>
      <div class="md:p-5 py-5">
         <div class="text-sm uppercase text-indigo-600 font-bold">Support</div>
         <a class="my-3 block" href="/#">Help Center <span class="text-teal-600 text-xs p-1"></span></a><a class="my-3 block" href="/#">Privacy Policy <span class="text-teal-600 text-xs p-1"></span></a><a class="my-3 block" href="/#">Conditions <span class="text-teal-600 text-xs p-1"></span></a> 
      </div>
      <div class="md:p-5 py-5">
         <div class="text-sm uppercase text-indigo-600 font-bold">Contact us</div>
         <a class="my-3 block" href="/#">XXX XXXX, YYYY 4 San Francisco, CA <span class="text-teal-600 text-xs p-1"></span></a><a class="my-3 block" href="/#">contact@company.com <span class="text-teal-600 text-xs p-1"></span></a> 
      </div>
   </div>
</div>

<div class="bg-black bg-opacity-5 pt-2">
   <div class="flex pb-5 px-3 m-auto pt-5 border-t border-indigo-800 text-gray-800 text-sm flex-col
      max-w-screen-lg items-center">
      <div class="md:flex-auto md:flex-row-reverse mt-2 flex-row flex">
         <a href="/#" class="w-6 mx-1">
            <img src='/Image/icons/m.svg'/>
         </a>
         <a href="/#" class="w-6 mx-1">
         <img src='/Image/icons/linkedin.svg'/>
         </a>
         <a href="/#" class="w-6 mx-1">
         <img src='/Image/icons/youtube.svg'/>
         </a>
         <a href="/#" class="w-6 mx-1">
         <img src='/Image/icons/facebook.svg'/> 
         </a>
         <a href="/#" class="w-6 mx-1">
         <img src='/Image/icons/twitter.svg'/>
         </a>
      </div>
      <div class="my-5">© Copyright 2023. All Rights Reserved.</div>
   </div>
</div>


    </>
  )
}

export default Footer